<?php
$conn = mysqli_connect("localhost", "root", "", "tugas1-main");

if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error());
}

session_start();
?>