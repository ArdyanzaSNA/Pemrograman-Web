<div class="card-group">

  <div class="card text-center">
    <div class="card-body">
      <i class="bi bi-instagram fs-3 text-danger"></i>
      <h5 class="mt-2">Instagram</h5>
      <a href="https://www.instagram.com/azaakrriiiii_?igsh=MXh5YmFtdXg5dnZpMg==" target="_blank" rel="noopener noreferrer">@azaakrriiiii_</a>
    </div>
  </div>

  <div class="card text-center">
    <div class="card-body">
      <i class="bi bi-whatsapp fs-3 text-success"></i>
      <h5 class="mt-2">WhatsApp</h5>
      <a href="https://wa.me/6285756639845" target="_blank" rel="noopener noreferrer">085756639845</a>
    </div>
  </div>

  <div class="card text-center">
    <div class="card-body">
      <i class="bi bi-envelope fs-3 text-primary"></i>
      <h5 class="mt-2">Email</h5>
      <a href="mailto:azzam05fikri@gmail.com">azzam05fikri@gmail.com</a>
    </div>
  </div>

  <div class="card text-center">
    <div class="card-body">
      <i class="bi bi-github fs-3 text-dark"></i>
      <h5 class="mt-2">GitHub</h5>
      <a href="https://github.com/azzam-lab" target="_blank" rel="noopener noreferrer">azzam-lab</a>
    </div>
  </div>

</div>