<div style="
background: linear-gradient(rgba(0,0,0,0.55), rgba(0,0,0,0.55)), url('header_bg.png') center/cover no-repeat;
padding:70px 20px;
text-align:center;
color:white;
">

  <h1 class="fw-bold mb-2">Personal Website</h1>
  <p class="mb-0">Belajar • Berkembang • Berkarya</p>

</div>