<!-- Profil Utama -->
<div class="row align-items-center mb-4">

  <div class="col-md-4 text-center">
    <img src="fotodiri.jpg" class="rounded-circle" style="width:200px; height:200px; object-fit:cover; border: 4px solid #0d6efd;">
  </div>

  <div class="col-md-8">
    <h2 class="fw-bold">Azzam Fikri</h2>
    <p class="text-muted">Mahasiswa Informatika</p>

    <p>
      Saya tertarik pada pengembangan web dan teknologi digital,
      khususnya backend development menggunakan PHP.
    </p>

    <span class="badge bg-primary">Web Dev</span>
    <span class="badge bg-success">Backend</span>

    <div class="mt-3" style="position:relative; z-index:10;">
      <a href="https://www.instagram.com/azaakrriiiii_?igsh=MXh5YmFtdXg5dnZpMg==" 
         target="_blank" 
         rel="noopener noreferrer"
         class="btn btn-danger btn-sm me-2">
        <i class="bi bi-instagram"></i> Instagram
      </a>
      <a href="https://github.com/azzam-lab" 
         target="_blank" 
         rel="noopener noreferrer"
         class="btn btn-dark btn-sm">
        <i class="bi bi-github"></i> GitHub
      </a>
    </div>
  </div>

</div>
