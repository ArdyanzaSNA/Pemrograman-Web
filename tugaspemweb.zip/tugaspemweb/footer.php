<div class="text-center py-3 mt-3" style="background:#e2e8f0; color:#334155;">
  <small>© 2026 - Azzam Fikri</small>
</div>