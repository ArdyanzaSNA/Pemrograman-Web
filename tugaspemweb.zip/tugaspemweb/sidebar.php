<div class="p-3 rounded-4 shadow-sm mb-3" style="background:white; text-align:center;">

  <img src="fotodiri2.jpg" class="rounded-circle mb-2" style="width:80px; height:80px; object-fit:cover; border: 3px solid #0d6efd;">

  <h6 class="fw-bold">Azzam Fikri</h6>
  <small class="text-muted">Mahasiswa Informatika</small>

</div>

<div class="p-3 rounded-4 shadow-sm" style="background:white;">

  <h6 class="fw-bold mb-3">Skills</h6>

  <span class="badge bg-primary">HTML</span>
  <span class="badge bg-success">PHP</span>
  <span class="badge bg-dark">Bootstrap</span>

</div>